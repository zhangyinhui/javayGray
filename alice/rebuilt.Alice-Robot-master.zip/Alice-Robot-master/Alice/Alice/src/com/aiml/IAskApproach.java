package com.aiml;

public interface IAskApproach {
	public String response(String input);
}
