package bitoflife.chatterbean.aiml;


import org.xml.sax.Attributes;


import bitoflife.chatterbean.Match;


public class A extends TemplateElement
{
  /*
  Constructors
  */

  public A(Attributes attributes)
  {
  }

  public A(Object... children)
  {
    super(children);
  }

  /*
  Methods
  */

  public String process(Match match)
  {
    return "";
  }
}