/*
Copyleft (C) 2005 H�lio Perroni Filho
xperroni@yahoo.com
ICQ: 2490863

This file is part of ChatterBean.

ChatterBean is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

ChatterBean is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with ChatterBean (look at the Documents/ directory); if not, either write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA, or visit (http://www.gnu.org/licenses/gpl.txt).
 */

package bitoflife.chatterbean.text;

import java.util.Arrays;

public class Request {
	/*
	 * Attributes
	 */
	// 这2个变量都是被规范化过的。
	private Sentence[] sentences;// 用户可能输入很多的句子，所以这是一个句子数组。
	private String original;

	/*
	 * Constructor
	 */

	public Request() {
	}

	public Request(String original) {
		this.original = original;
	}

	public Request(String original, Sentence... sentences) {
		this.original = original;
		this.sentences = sentences;
	}

	/*
	 * Methods
	 */

	public boolean empty() {
		return (sentences == null || sentences.length == 0);
	}

	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Request))
			return false;

		Request compared = (Request) obj;
		return original.equals(compared.original)
				&& Arrays.equals(sentences, compared.sentences);
	}

	/**
	 * 取倒数第 index 个句子。
	 * 
	 * @param index
	 * @return
	 */
	public Sentence lastSentence(int index) {
		return sentences[sentences.length - (1 + index)];
	}

	public String toString() {
		String tempOriginal = "";
		if (original == null)
			tempOriginal = "null";
		else
			tempOriginal = original.replace(" ", "#");
		StringBuffer output = new StringBuffer("");
		output.append("-----------Request-----------\n").append(
				"[original]:" + tempOriginal + "\n");
		if (sentences != null)
			for (int i = 0; i < sentences.length; i++) {
				output.append("[sentence " + i + "]:" + sentences[i].toString()
						+ "\n");
			}
		else
			output.append("[sentence]:null");
		return output.toString();
	}

	public String trimOriginal() {
		return original.trim();
	}

	/*
	 * Properties
	 */

	public String getOriginal() {
		return original;
	}

	public void setOriginal(String original) {
		this.original = original;
	}

	public Sentence[] getSentences() {
		return sentences;
	}

	public Sentence getSentences(int index) {
		return sentences[index];
	}

	public void setSentences(Sentence[] sentences) {
		this.sentences = sentences;
	}

}